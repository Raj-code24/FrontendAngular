export class Customer {

    id: number;
    firstName: String;
    lastName: String;
    email: String;
}
