import { Customer } from './customer';

describe('Employee', () => {
  it('should create an instance', () => {
    expect(new Customer()).toBeTruthy();
  });
});
