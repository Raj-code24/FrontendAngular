import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { ActivatedRoute } from '@angular/router';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-customer-details',
  templateUrl: './customer-details.component.html',
  styleUrls: ['./customer-details.component.css']
})
export class CustomerDetailsComponent implements OnInit {
  
  id: number;
  employee: Customer;

  constructor(
    private route: ActivatedRoute,
    private employeeService: CustomerService
    ){}


  ngOnInit(): void {

    this.id = this.route.snapshot.params['id'];

    this.employee = new Customer();
    this.employeeService.getCustomerById(this.id).subscribe( data => {
      this.employee= data;
    })
  }

}
