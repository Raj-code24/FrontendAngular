using CodeCustomer.API.Models.Domain;

#pragma warning disable CA1050 // Declare types in namespaces

namespace CodeCustomer.API.Repositories.Implementation
{
public class CustomerRepository : ICustomerRepository
#pragma warning restore CA1050 // Declare types in namespaces
{
    private List<Customer> customers = new List<Customer>();


    public IEnumerable<Customer> GetCustomers()
    {
        return customers;
    }

    public Customer GetCustomerById(int id)
    {
        return customers.FirstOrDefault(c => c.Id == id);
    }

    public void AddCustomer(Customer customer)
    {
        customers.Add(customer);
    }

    public void UpdateCustomer(Customer customer)
    {
        var existingCustomer = GetCustomerById(customer.Id);
        if (existingCustomer != null)
        {
            existingCustomer.FirstName = customer.FirstName;
            existingCustomer.LastName = customer.LastName;
            existingCustomer.Email = customer.Email;
            existingCustomer.LastUpdatedDateTime = DateTime.Now;
        }
    }

    public void DeleteCustomer(int id)
    {
        var existingCustomer = GetCustomerById(id);
        if (existingCustomer != null)
        {
            customers.Remove(existingCustomer);
        }
    }
}
}