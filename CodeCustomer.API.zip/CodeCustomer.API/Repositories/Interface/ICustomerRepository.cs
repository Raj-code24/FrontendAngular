using CodeCustomer.API.Models.Domain;

public interface ICustomerRepository
{
    IEnumerable<Customer> GetCustomers();
    Customer GetCustomerById(int id);
    void AddCustomer(Customer customer);
    void UpdateCustomer(Customer customer);
    void DeleteCustomer(int id);
}