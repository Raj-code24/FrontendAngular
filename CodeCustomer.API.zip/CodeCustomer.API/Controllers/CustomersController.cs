using CodePulse.API.Data;
using CodePulse.API.Models.Domain;
using CodePulse.API.Models.DTO;
using CodePulse.API.Repositories.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CodePulse.API.Controllers
{
[ApiController]
[Route("api/customers")]
public class CustomerController : ControllerBase
{
    private readonly ICustomerRepository customerRepository;

    public CustomerController(ICustomerRepository customerRepository)
    {
        this.customerRepository = customerRepository;
    }

    [HttpGet]
    public IActionResult GetCustomers()
    {
        var customers = customerRepository.GetCustomers();
        return Ok(customers);
    }

    [HttpGet("{id}")]
    public IActionResult GetCustomer(int id)
    {
        var customer = customerRepository.GetCustomerById(id);
        if (customer == null)
        {
            return NotFound();
        }
        return Ok(customer);
    }

    [HttpPost]
    public IActionResult AddCustomer([FromBody] Customer customer)
    {
        if (customer == null)
        {
            return BadRequest();
        }
        customerRepository.AddCustomer(customer);
        return CreatedAtAction(nameof(GetCustomer), new { id = customer.Id }, customer);
    }

    [HttpPut("{id}")]
    public IActionResult UpdateCustomer(int id, [FromBody] Customer customer)
    {
        if (customer == null || id != customer.Id)
        {
            return BadRequest();
        }
        var existingCustomer = customerRepository.GetCustomerById(id);
        if (existingCustomer == null)
        {
            return NotFound();
        }
        customerRepository.UpdateCustomer(customer);
        return NoContent();
    }

    [HttpDelete("{id}")]
    public IActionResult DeleteCustomer(int id)
    {
        var existingCustomer = customerRepository.GetCustomerById(id);
        if (existingCustomer == null)
        {
            return NotFound();
        }
        customerRepository.DeleteCustomer(id);
        return NoContent();
    }
}
}